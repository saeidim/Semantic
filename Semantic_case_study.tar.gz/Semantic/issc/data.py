"""CIFAR-10 loading utilities.

The case study uses the original CIFAR-10 python batches (Krizhevsky, 2009).
Place the extracted folder ``cifar-10-batches-py`` under ``data/`` or run
``python scripts/get_data.py``. File integrity is checked against the
official MD5 checksums published with the dataset.
"""
from __future__ import annotations

import hashlib
import os
import pickle

import numpy as np

DATA_DIR = os.environ.get(
    "ISSC_DATA", os.path.join(os.path.dirname(__file__), "..", "data", "cifar-10-batches-py")
)

# Official checksums of the CIFAR-10 python version.
MD5 = {
    "data_batch_1": "c99cafc152244af753f735de768cd75f",
    "data_batch_2": "d4bba439e000b95fd0a9bffe97cbabec",
    "data_batch_3": "54ebc095f3ab1f0389bbae665268c751",
    "data_batch_4": "634d18415352ddfa80567beed471001a",
    "data_batch_5": "482c414d41f54cd18b22e5b47cb7c3cb",
    "test_batch": "40351d587109b95175f43aff81a1287e",
}

MEAN = np.array([0.4914, 0.4822, 0.4465], dtype=np.float32)
STD = np.array([0.2470, 0.2435, 0.2616], dtype=np.float32)


def _md5(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_batch(name: str, check: bool = True):
    path = os.path.join(DATA_DIR, name)
    if check and _md5(path) != MD5[name]:
        raise RuntimeError(f"Checksum mismatch for {path}")
    with open(path, "rb") as f:
        d = pickle.load(f, encoding="bytes")
    x = d[b"data"].reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)  # NHWC uint8
    y = np.asarray(d[b"labels"], dtype=np.int32)
    return x, y


def load_cifar10(check: bool = True):
    """Return (x_train, y_train, x_test, y_test); images are uint8 NHWC."""
    xs, ys = zip(*[_load_batch(f"data_batch_{i}", check) for i in range(1, 6)])
    x_tr, y_tr = np.concatenate(xs), np.concatenate(ys)
    x_te, y_te = _load_batch("test_batch", check)
    return x_tr, y_tr, x_te, y_te


def normalize(x_uint8: np.ndarray) -> np.ndarray:
    return ((x_uint8.astype(np.float32) / 255.0) - MEAN) / STD


def augment(x: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Random 4-pixel-padded crop and horizontal flip (standard CIFAR-10 recipe)."""
    n = x.shape[0]
    xp = np.pad(x, ((0, 0), (4, 4), (4, 4), (0, 0)), mode="reflect")
    ox = rng.integers(0, 9, n)
    oy = rng.integers(0, 9, n)
    out = np.empty_like(x)
    for i in range(n):
        out[i] = xp[i, oy[i]:oy[i] + 32, ox[i]:ox[i] + 32]
    flip = rng.random(n) < 0.5
    out[flip] = out[flip, :, ::-1]
    return out
