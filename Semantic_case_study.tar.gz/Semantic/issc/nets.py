"""Pure-JAX networks used by the case study.

* ``backbone``: a small CNN trained once on clean CIFAR-10. Its 256-d
  penultimate activation is the semantic feature shared by transmitter and
  receiver (the "knowledge base" of the link).
* ``SemCodec``: a trainable semantic encoder (linear map to 2k reals, then
  per-image power normalisation to k unit-power complex symbols) and a
  linear task head at the receiver. The analog variant sends the normalised
  symbols directly (DeepJSCC-style); the digital variant maps each real
  dimension to one QPSK bit through a straight-through estimator.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np

# ---------------------------------------------------------------- backbone
CONV_SPECS = [(3, 32), (32, 32), "pool", (32, 64), "pool", (64, 128), "pool"]
FEAT_DIM = 256
N_CLASSES = 10


def _he(key, shape, fan_in):
    return jax.random.normal(key, shape) * jnp.sqrt(2.0 / fan_in)


def init_backbone(key):
    params = {"conv": [], "fc": None, "cls": None}
    for spec in CONV_SPECS:
        if spec == "pool":
            continue
        cin, cout = spec
        key, k1 = jax.random.split(key)
        params["conv"].append({"w": _he(k1, (3, 3, cin, cout), 9 * cin), "b": jnp.zeros(cout)})
    key, k1, k2 = jax.random.split(key, 3)
    params["fc"] = {"w": _he(k1, (4 * 4 * 128, FEAT_DIM), 4 * 4 * 128), "b": jnp.zeros(FEAT_DIM)}
    params["cls"] = {"w": _he(k2, (FEAT_DIM, N_CLASSES), FEAT_DIM) * 0.5, "b": jnp.zeros(N_CLASSES)}
    return params


def _conv(x, w, b):
    y = jax.lax.conv_general_dilated(x, w, (1, 1), "SAME", dimension_numbers=("NHWC", "HWIO", "NHWC"))
    return y + b


def _pool(x):
    return jax.lax.reduce_window(x, -jnp.inf, jax.lax.max, (1, 2, 2, 1), (1, 2, 2, 1), "VALID")


def features(params, x):
    """Semantic feature f(x) in R^256 (post-ReLU)."""
    i = 0
    for spec in CONV_SPECS:
        if spec == "pool":
            x = _pool(x)
        else:
            p = params["conv"][i]
            x = jax.nn.relu(_conv(x, p["w"], p["b"]))
            i += 1
    x = x.reshape(x.shape[0], -1)
    return jax.nn.relu(x @ params["fc"]["w"] + params["fc"]["b"])


def backbone_logits(params, x):
    f = features(params, x)
    return f @ params["cls"]["w"] + params["cls"]["b"]


# ---------------------------------------------------------------- semantic codec
def init_codec(key, k_sym: int, feat_dim: int = FEAT_DIM):
    k1, k2 = jax.random.split(key)
    d = 2 * k_sym
    return {
        "enc": {"w": jax.random.normal(k1, (feat_dim, d)) / jnp.sqrt(feat_dim), "b": jnp.zeros(d)},
        "dec": {"w": jax.random.normal(k2, (d, N_CLASSES)) / jnp.sqrt(d), "b": jnp.zeros(N_CLASSES)},
    }


def encode_real(params, f):
    """Pre-modulation real vector z in R^{2k}."""
    return f @ params["enc"]["w"] + params["enc"]["b"]


def power_normalise(z):
    """Scale each row so that the mean power per real dimension is 1/2,
    i.e. k complex symbols of unit average power."""
    p = jnp.mean(z ** 2, axis=-1, keepdims=True)
    return z / jnp.sqrt(2.0 * p + 1e-12)


def modulate(params, f, digital: bool):
    """Return real-valued stacked symbols [Re s, Im s] with E|s|^2 = 1."""
    z = encode_real(params, f)
    if not digital:
        return power_normalise(z)
    # QPSK via straight-through sign: forward = sign(z)/sqrt(2), backward = tanh'.
    soft = jnp.tanh(z)
    hard = jnp.sign(z)
    q = soft + jax.lax.stop_gradient(hard - soft)
    return q / jnp.sqrt(2.0)


def decode(params, y):
    return y @ params["dec"]["w"] + params["dec"]["b"]


def to_complex(s_real):
    k = s_real.shape[-1] // 2
    return s_real[..., :k] + 1j * s_real[..., k:]


def to_real(s_cplx):
    return np.concatenate([s_cplx.real, s_cplx.imag], axis=-1)
