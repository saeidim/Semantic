"""Array, channel and sensing utilities for the ISSC case study.

Conventions
-----------
* Uniform linear array, half-wavelength spacing, element n = 0..N-1.
* Steering vector a(theta) = exp(j*pi*n*sin(theta)) (unnormalised, ||a||^2 = N).
* A transmit beam w (||w|| = 1) radiates gain |a(theta)^T w|^2 towards theta.
* Downlink: y = h^T x + n, with h = sqrt(beta)*(sqrt(K/(K+1)) a(theta) + sqrt(1/(K+1)) h_s).
* Monostatic echo: Y = b a_r(theta) a_t(theta)^T X + Z.
"""
from __future__ import annotations

import numpy as np

DEG = np.pi / 180.0


def steer(n_ant: int, theta: float | np.ndarray) -> np.ndarray:
    n = np.arange(n_ant)
    th = np.atleast_1d(theta)
    a = np.exp(1j * np.pi * np.outer(np.sin(th), n))
    return a[0] if np.ndim(theta) == 0 else a


def dsteer(n_ant: int, theta: float) -> np.ndarray:
    n = np.arange(n_ant)
    return 1j * np.pi * n * np.cos(theta) * steer(n_ant, theta)


def mrt(n_ant: int, theta: float) -> np.ndarray:
    """Unit-norm beam matched to direction theta."""
    return np.conj(steer(n_ant, theta)) / np.sqrt(n_ant)


def null_project(v: np.ndarray, directions, n_ant: int) -> np.ndarray:
    """Project beam v onto the orthogonal complement of conj(a(dir)) so that
    a(dir)^T v = 0 for every listed direction; returns a unit-norm beam."""
    B = np.stack([np.conj(steer(n_ant, d)) for d in directions], axis=1)
    P = np.eye(n_ant) - B @ np.linalg.pinv(B)
    u = P @ v
    return u / np.linalg.norm(u)


def gain(beam: np.ndarray, n_ant: int, theta) -> np.ndarray:
    return np.abs(steer(n_ant, theta) @ beam) ** 2


def hpbw(n_ant: int) -> float:
    """Half-power beamwidth (rad) at broadside for a lambda/2 ULA."""
    return 2 * np.arcsin(1.3916 / (np.pi * n_ant / 2))


def rician(rng, n_draw: int, n_ant: int, theta: float, k_factor_db: float) -> np.ndarray:
    """Unit-mean-power Rician channel vectors (per antenna) of shape (n_draw, n_ant)."""
    K = 10 ** (k_factor_db / 10)
    los = steer(n_ant, theta)[None, :]
    nlos = (rng.standard_normal((n_draw, n_ant)) + 1j * rng.standard_normal((n_draw, n_ant))) / np.sqrt(2)
    return np.sqrt(K / (K + 1)) * los + np.sqrt(1 / (K + 1)) * nlos


def crb_angle(R: np.ndarray, theta: float, snr_s: float, n_rx: int | None = None) -> float:
    """CRB (rad^2) of the target angle for a monostatic colocated MIMO radar
    with unknown complex reflection coefficient.

    R      : transmit covariance (N_t x N_t), trace-normalised to the total power 1.
    snr_s  : |b|^2 L P / sigma_s^2, the echo SNR per receive antenna integrated over L snapshots.
    """
    nt = R.shape[0]
    nr = n_rx or nt
    at, ar = steer(nt, theta), steer(nr, theta)
    dat, dar = dsteer(nt, theta), dsteer(nr, theta)
    A = np.outer(ar, at)
    dA = np.outer(dar, at) + np.outer(ar, dat)
    t11 = np.real(np.trace(dA @ R @ dA.conj().T))
    t12 = np.trace(A @ R @ dA.conj().T)
    t22 = np.real(np.trace(A @ R @ A.conj().T))
    denom = t11 - np.abs(t12) ** 2 / t22
    return 1.0 / (2.0 * snr_s * denom)


def ml_angle(Y: np.ndarray, X: np.ndarray, grid: np.ndarray) -> float:
    """Maximum-likelihood angle estimate for a single target on a search grid,
    refined by golden-section search around the best grid point."""
    nr, nt = Y.shape[0], X.shape[0]
    Ar = steer(nr, grid)            # (G, nr)
    At = steer(nt, grid)            # (G, nt)
    YXh = Y @ X.conj().T            # (nr, nt)
    num = np.abs(np.einsum("gi,ij,gj->g", Ar.conj(), YXh, At.conj())) ** 2
    den = np.sum(np.abs(At @ X) ** 2, axis=1)
    k = int(np.argmax(num / den))

    def f(th):
        ar, at = steer(nr, th), steer(nt, th)
        return -np.abs(ar.conj() @ YXh @ at.conj()) ** 2 / np.sum(np.abs(at @ X) ** 2)

    lo = grid[max(k - 1, 0)]
    hi = grid[min(k + 1, len(grid) - 1)]
    g = (np.sqrt(5) - 1) / 2
    c, d = hi - g * (hi - lo), lo + g * (hi - lo)
    for _ in range(40):
        if f(c) < f(d):
            hi = d
        else:
            lo = c
        c, d = hi - g * (hi - lo), lo + g * (hi - lo)
    return 0.5 * (lo + hi)


def ml_angle_batch(U: np.ndarray, grid: np.ndarray, n_rx: int) -> np.ndarray:
    """Vectorised ML angle estimates for many independent snapshots.

    For a rank-one transmit signal X = sqrt(p) w z^T with unit-modulus streams z,
    the ML angle metric |a_r(th)^H Y X^H a_t(th)^*|^2 / ||a_t(th)^T X||^2 reduces to
    |a_r(th)^H u|^2 with the matched vector u = Y z^*, because the transmit-side
    factor |a_t(th)^T w|^2 cancels between numerator and denominator. U stacks one
    such vector per trial. The grid maximum is refined by parabolic interpolation.
    """
    A = steer(n_rx, grid)                       # (G, n_rx)
    sc = np.abs(U @ A.conj().T) ** 2            # (T, G)
    k = np.argmax(sc, axis=1)
    k = np.clip(k, 1, len(grid) - 2)
    t = np.arange(len(U))
    y0, y1, y2 = sc[t, k - 1], sc[t, k], sc[t, k + 1]
    den = y0 - 2 * y1 + y2
    shift = np.where(np.abs(den) > 1e-12, 0.5 * (y0 - y2) / np.where(den == 0, 1, den), 0.0)
    shift = np.clip(shift, -1, 1)
    step = grid[1] - grid[0]
    return grid[k] + shift * step


# ---------------------------------------------------------------- OFDM radar
def ofdm_range_profile(S: np.ndarray, Y: np.ndarray, method: str) -> np.ndarray:
    """Coherently integrated range profile |r|^2 from M OFDM symbols.

    S, Y : (M, N_sc) transmitted and received frequency-domain symbols.
    method = 'reciprocal' (element-wise division, the classical OFDM radar
    processor) or 'matched' (conjugate multiplication).
    """
    if method == "reciprocal":
        D = Y / S
    elif method == "matched":
        D = Y * np.conj(S) / np.mean(np.abs(S) ** 2, axis=1, keepdims=True)
    else:
        raise ValueError(method)
    r = np.fft.ifft(D, axis=1)          # per-symbol range profile
    return np.abs(r.mean(axis=0)) ** 2  # coherent integration (static targets)
