"""Semantic-link evaluation from the pre-computed error tables.

Metric (as in the companion survey on time-varying channels): the
*clean-conditioned semantic outage* is the fraction of test images that the
link classifies correctly without channel noise but misclassifies after the
channel. It isolates what the channel destroys from what the codec never
knew. Task accuracy under the channel is also available.
"""
from __future__ import annotations

import os

import numpy as np

RES = os.path.join(os.path.dirname(__file__), "..", "results")


class Tables:
    def __init__(self, path: str | None = None):
        d = np.load(path or os.path.join(RES, "perr_tables.npz"))
        self.grid = d["snr_grid_db"]
        self.y = d["y_te"]
        self.perr, self.ok, self.sym = {}, {}, {}
        for key in d.files:
            if key.startswith("perr_"):
                self.perr[key[5:]] = d[key]
            elif key.startswith("ok_"):
                self.ok[key[3:]] = d[key]
            elif key.startswith("sym_"):
                self.sym[key[4:]] = d[key]
        self.seeds = sorted({int(k.split("_")[1]) for k in self.perr})

    def _interp(self, name: str, snr_db: np.ndarray) -> np.ndarray:
        """Per-image error probability at per-image SNR (dB). snr_db: (..., N_test)."""
        tab = self.perr[name]                              # (N, G)
        g = np.clip(snr_db, self.grid[0], self.grid[-1])
        pos = (g - self.grid[0]) / (self.grid[1] - self.grid[0])
        i0 = np.clip(np.floor(pos).astype(int), 0, len(self.grid) - 2)
        w = pos - i0
        idx = np.arange(tab.shape[0])
        return (1 - w) * tab[idx, i0] + w * tab[idx, i0 + 1]

    def outage(self, kind: str, seed: int, snr_db: np.ndarray) -> np.ndarray:
        """Clean-conditioned outage; returns one value per leading index of snr_db."""
        name = f"{kind}_{seed}"
        p = self._interp(name, snr_db)
        ok = self.ok[name]
        return (p[..., ok]).mean(axis=-1)

    def accuracy(self, kind: str, seed: int, snr_db: np.ndarray) -> np.ndarray:
        return 1.0 - self._interp(f"{kind}_{seed}", snr_db).mean(axis=-1)

    def clean_accuracy(self, kind: str, seed: int) -> float:
        return float(self.ok[f"{kind}_{seed}"].mean())


def summarize(values: np.ndarray) -> dict:
    """values: (S seeds, R Monte Carlo trials, ...) -> mean, seed std, MC std."""
    v = np.asarray(values)
    return {
        "mean": v.mean(axis=(0, 1)).tolist(),
        "seed_std": v.mean(axis=1).std(axis=0, ddof=1).tolist() if v.shape[0] > 1 else 0.0,
        "mc_std": v.std(axis=1, ddof=1).mean(axis=0).tolist() if v.shape[1] > 1 else 0.0,
    }
