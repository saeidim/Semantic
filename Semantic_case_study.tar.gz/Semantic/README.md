# Semantic: case study of integrated sensing and semantic communication (ISSC)

This repository reproduces the case study (Section XI) of the survey

> S. Iranmanesh, "Sensing for Meaning, Meaning for Sensing: A Survey of Integrated
> Sensing and Semantic Communication," submitted to *IEEE Communications Surveys & Tutorials*.

The study holds the task (CIFAR-10 classification), the semantic representation
(k = 32 complex symbols per image), the metric (clean-conditioned semantic outage)
and the randomness protocol (5 codec seeds x R Monte Carlo trials) fixed, and
switches on one coupling mechanism between sensing and semantic communication at a time:

| Mechanism | Diagnosis | Remedy |
|-----------|-----------|--------|
| K1 resource  | isotropic probing interferes with the semantic user | null-space probing |
| K2 waveform  | analog semantic symbols used as the OFDM radar waveform | digital (QPSK) semantic symbols |
| K3 context   | narrow beam steered at a noisy sensed angle | uncertainty-aware beam width |
| K4 task      | physically optimal (min sum-CRB) sensing allocation | task-aware allocation |
| K5 security  | the sensed target decodes the semantic stream | probing signal used as artificial noise |

## Requirements

Python 3.10+, CPU only. Install with

    pip install -r requirements.txt

CIFAR-10 (python version) is downloaded to `data/` on first use and checked against
the official MD5 sums.

## Running

    python scripts/train_backbone.py      # ~40 min on one CPU core; resumable
    python scripts/train_codecs.py        # analog + digital codecs, 5 seeds
    python scripts/run_experiments.py     # K1..K5 -> results/k*.json
    python scripts/make_figures.py eps    # figures/fig_case_a.eps, fig_case_b.eps
    python scripts/summarize.py           # numbers quoted in the paper

`scripts/train_backbone.py` writes a checkpoint every 50 steps and resumes
automatically; `scripts/keepalive.sh` relaunches it if it is interrupted.

## Layout

    issc/data.py        CIFAR-10 loader (MD5-checked), normalisation, augmentation
    issc/nets.py        CNN backbone (shared knowledge base) and semantic codecs
    issc/isac.py        ULA steering, beams, Rician channels, angle CRB, ML estimator, OFDM radar
    issc/semantic.py    per-image error tables and the clean-conditioned outage metric
    scripts/            training, experiments, figures, summary

## Randomness

Every reported quantity averages 5 codec seeds and R Monte Carlo trials. The JSON
files store the mean, the standard deviation across seeds (`seed_std`) and the mean
standard deviation across trials (`mc_std`) separately.

## License

MIT
