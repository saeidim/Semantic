"""Print every case-study number quoted in the paper from results/k*.json."""
import json
import os

import numpy as np

RES = os.path.join(os.path.dirname(__file__), "..", "results")


def load(n):
    with open(os.path.join(RES, f"{n}.json")) as f:
        return json.load(f)


def interp_log(x, xs, ys):
    """Interpolate ys(xs) at x on a log axis; xs must be monotone."""
    xs, ys = np.asarray(xs), np.asarray(ys)
    o = np.argsort(xs)
    return float(np.interp(np.log(x), np.log(xs[o]), ys[o]))


def k1():
    d = load("k1")
    print("== K1 resource coupling")
    for key in ("separated", "coupled"):
        r = np.array(d[key]["rmse_deg"])
        o = 100 * np.array(d[key]["outage"]["mean"])
        print(f"  {key:9s} RMSE range {r.min():.3f}-{r.max():.3f} deg, outage {o.min():.2f}-{o.max():.2f} %,"
              f" max seed std {100 * np.max(d[key]['outage']['seed_std']):.2f} pp,"
              f" max MC std {100 * np.max(d[key]['outage']['mc_std']):.2f} pp")
        print(f"            outage at RMSE 2.0 deg: {interp_log(2.0, r, o):.2f} %;"
              f" RMSE at outage 2 %: {float(np.interp(2.0, o, r)):.3f} deg")
    print(f"  sensing-only RMSE bound {d['rmse_sensing_only_deg']:.3f} deg")


def k2():
    d = load("k2")
    print("== K2 waveform coupling")
    for kind, st in d["symbol_stats"].items():
        print(f"  {kind:8s} E[1/|s|^2]={st['e_inv']:.2f} ({10 * np.log10(st['e_inv']):.1f} dB)"
              f" var|s|^2={st['var_pow']:.3f} amplitude PAPR={st['papr_sym_db']:.1f} dB")
    snr = np.array(d["snr_db"])
    for key in ("pilot_reciprocal", "pilot_matched", "digital_reciprocal", "digital_matched",
                "analog_reciprocal", "analog_matched"):
        pd = np.array(d[key]["pd"]["mean"])
        i = np.where(pd >= 0.9)[0]
        print(f"  {key:18s} SNR for Pd>=0.9: {snr[i[0]] if len(i) else 'never':>5}  max Pd {pd.max():.2f}"
              f"  median floor {d[key]['floor_db']['mean'][0]:.1f} dB")
    for kind in ("analog", "digital"):
        s = d[f"sem_{kind}"]
        g = np.array(s["snr_db"])
        o = 100 * np.array(s["outage"]["mean"])
        print(f"  semantic {kind:7s} clean acc {100 * s['clean_acc_mean']:.2f} +- {100 * s['clean_acc_std']:.2f} %;"
              + " ".join(f"{v:+.0f}dB:{o[g == v][0]:.2f}%" for v in (-5, 0, 5, 10, 20)))


def k3():
    d = load("k3")
    e = np.array(d["eps"])
    print("== K3 context coupling")
    print(f"  HPBW {d['hpbw_deg']:.2f} deg; crossover eps* {d.get('eps_star', float('nan')):.3f}"
          f" (sigma_theta = {d.get('eps_star', float('nan')) * d['hpbw_deg']:.2f} deg)")
    for M in d["sizes"]:
        m = 100 * np.array(d[f"M{M}"]["mean"])
        print(f"  M={M:2d} outage at eps=0.01: {m[0]:.2f} %, at eps=1: {interp_log(1.0, e, m):.2f} %, at eps=2: {m[-1]:.2f} %")
    best = np.min(np.stack([np.array(d[f"M{M}"]["mean"]) for M in d["sizes"]]), axis=0)
    ad = np.array(d["adaptive"]["mean"])
    print(f"  adaptive: at eps=1 {100 * interp_log(1.0, e, ad):.2f} %, at eps=2 {100 * ad[-1]:.2f} %;"
          f" max gap to best fixed beam {100 * np.max(ad - best):.2f} pp; choices {d['choice']}")


def k4():
    d = load("k4")
    fr = np.array(d["frac"])
    pe = np.array(d["pe"])
    sc = np.array(d["sum_crb"]) / (np.pi / 180) ** 2
    print(f"== K4 task coupling (echo SNR {d.get('snr_s_db')} dB, {d.get('n_mc')} ML trials per target)")
    for name, f in d["designs"].items():
        i = np.argmin(abs(fr - f))
        mc = d["mc"][name]
        print(f"  {name:12s} share on A {f:.3f}: sum CRB {sc[i]:.4f} deg^2, predicted Pe {100 * pe[i]:.3f} %,"
              f" ML Pe {100 * mc['pe']:.3f} %, ML RMSE A {mc['rmse_A_deg']:.3f} deg, B {mc['rmse_B_deg']:.3f} deg")


def k5():
    d = load("k5")
    print(f"== K5 security coupling (zeta = {d['zeta']})")
    for key in ("shared_stream", "known_probe", "an_probe"):
        r = d[key]
        pa = 100 * np.array(r["eve_probe_acc"]["mean"])
        print(f"  {key:13s} RMSE {r['rmse_deg']:.3f} deg; Bob acc {100 * r['bob_acc']['mean'][0]:.2f} %,"
              f" Bob outage {100 * r['bob_outage']['mean'][0]:.2f} %; Eve with leaked KB {100 * r['eve_kb_acc']['mean'][0]:.2f} %")
        print("                probe acc " + " ".join(f"n={n}:{a:.2f}%" for n, a in zip(d["n_train"], pa)))


if __name__ == "__main__":
    for f in (k1, k2, k3, k4, k5):
        try:
            f()
        except FileNotFoundError as e:
            print("missing", e)
