"""Stage 4: draw the case-study figures (EPS for the paper, PNG for preview).

Usage: python scripts/make_figures.py [eps|png]
"""
from __future__ import annotations

import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

RES = os.path.join(os.path.dirname(__file__), "..", "results")
OUT = os.path.join(os.path.dirname(__file__), "..", "figures")
EXT = sys.argv[1] if len(sys.argv) > 1 else "eps"
plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 7,
                     "axes.labelsize": 7, "legend.fontsize": 6, "xtick.labelsize": 6.5, "ytick.labelsize": 6.5,
                     "lines.linewidth": 1.0, "lines.markersize": 3.2, "axes.linewidth": 0.6,
                     "ps.fonttype": 42, "pdf.fonttype": 42, "mathtext.fontset": "dejavuserif"})


def load(name):
    with open(os.path.join(RES, f"{name}.json")) as f:
        return json.load(f)


def tot(d):
    """Total spread combining seed and Monte Carlo components."""
    return np.sqrt(np.asarray(d["seed_std"]) ** 2 + np.asarray(d["mc_std"]) ** 2)


def fig_a():
    k1, k2 = load("k1"), load("k2")
    fig, axs = plt.subplots(1, 3, figsize=(7.16, 2.15))
    # (a) K1 semantic-sensing front
    ax = axs[0]
    for key, lab, st in [("separated", "Isotropic probing", "o--"), ("coupled", "Null-space probing", "s-")]:
        x = np.array(k1[key]["rmse_deg"])
        y = 100 * np.array(k1[key]["outage"]["mean"])
        e = 100 * tot(k1[key]["outage"])
        ax.errorbar(x, y, yerr=e, fmt=st, color="k" if key == "coupled" else "0.45", mfc="white",
                    capsize=1.2, elinewidth=0.5, label=lab)
    ax.set_xscale("log")
    ax.set_xlabel("Angle RMSE bound (deg)")
    ax.set_ylabel("Semantic outage (%)")
    ax.set_title("(a) K1: resource coupling", fontsize=7)
    ax.set_ylim(0.6, 9.2)                      # headroom so the legend clears every curve
    ax.set_yticks([1, 2, 3, 4, 5, 6])
    ax.legend(frameon=False, loc="upper right", fontsize=6)
    ax.grid(lw=0.3, ls=":")
    # (b) K2 weak-target detection
    ax = axs[1]
    snr = np.array(k2["snr_db"])
    for kind, col, mk in [("pilot", "0.6", "^"), ("digital", "k", "s"), ("analog", "k", "o")]:
        for meth, ls in [("reciprocal", "-"), ("matched", "--")]:
            if kind == "pilot" and meth == "matched":
                continue
            d = k2[f"{kind}_{meth}"]["pd"]
            lab = {"pilot": "Pilot", "digital": "Digital", "analog": "Analog"}[kind] + \
                ("" if kind == "pilot" else (", recip." if meth == "reciprocal" else ", matched"))
            ax.plot(snr, np.array(d["mean"]), ls, marker=mk, color=col, mfc="white" if kind != "analog" else col,
                    label=lab, markevery=2)
    ax.set_xlabel("Strong-target echo SNR (dB)")
    ax.set_ylabel("Weak-target detection prob.")
    ax.set_title("(b) K2: sensing with semantic symbols", fontsize=7)
    ax.set_ylim(-0.02, 1.62)                   # blank band above the saturation level
    ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_xlim(-21, 21)
    ax.grid(lw=0.3, ls=":")
    ax.legend(frameon=False, loc="upper left", fontsize=5.4, ncol=2, columnspacing=0.7,
              handlelength=1.8, handletextpad=0.4, borderaxespad=0.15)
    # (c) K2 semantic cost of the digital remedy
    ax = axs[2]
    for kind, st in [("analog", "o-"), ("digital", "s--")]:
        d = k2[f"sem_{kind}"]
        x = np.array(d["snr_db"])
        ax.plot(x, 100 * np.array(d["outage"]["mean"]), st, color="k", mfc="white" if kind == "digital" else "k",
                markevery=2, label=f"{kind.capitalize()} (clean acc. {100 * d['clean_acc_mean']:.1f}%)")
    ax.set_yscale("log")
    ax.set_xlabel("Post-equalization SNR (dB)")
    ax.set_ylabel("Semantic outage (%)")
    ax.set_title("(c) K2: semantic side of the two codecs", fontsize=7)
    ax.set_ylim(0.2, 200)                      # blank decade at the top for the legend
    ax.set_yticks([1, 10])
    ax.grid(lw=0.3, ls=":", which="both")
    ax.legend(frameon=False, loc="upper right", fontsize=5.8, handlelength=1.8, handletextpad=0.4)
    fig.subplots_adjust(left=0.065, right=0.985, bottom=0.21, top=0.9, wspace=0.34)
    fig.savefig(os.path.join(OUT, f"fig_case_a.{EXT}"), dpi=160 if EXT == "png" else None)
    plt.close(fig)


def fig_b():
    k3, k4, k5 = load("k3"), load("k4"), load("k5")
    fig, axs = plt.subplots(1, 3, figsize=(7.16, 2.15))
    # (d) K3 context reliability
    ax = axs[0]
    eps = np.array(k3["eps"])
    for key, lab, st, col in [("M16", "Narrow beam ($M$=16)", "s-", "k"), ("M4", "Wide beam ($M$=4)", "^--", "0.4"),
                              ("M1", "No context ($M$=1)", "o:", "0.55")]:
        ax.plot(eps, 100 * np.array(k3[key]["mean"]), st, color=col, mfc="white", markevery=3, label=lab)
    ax.plot(eps, 100 * np.array(k3["adaptive"]["mean"]), "-", color="#b30000", lw=1.4, label="Uncertainty-aware")
    ax.set_ylim(0, 31)                         # blank band above the curves for the legend
    ax.set_yticks([0, 5, 10, 15, 20])
    if "eps_star" in k3:
        ax.axvline(k3["eps_star"], color="0.3", lw=0.6, ls="-.")
        ax.text(k3["eps_star"] * 1.15, 23.5, r"$\varepsilon^\star=$" + f"{k3['eps_star']:.2f}",
                fontsize=6, color="0.3")
    ax.set_xscale("log")
    ax.set_xlabel(r"Context error $\varepsilon=\sigma_\theta/\theta_{3\mathrm{dB}}$")
    ax.set_ylabel("Semantic outage (%)")
    ax.set_title("(d) K3: context coupling", fontsize=7)
    ax.legend(frameon=False, loc="upper left", fontsize=5.4, labelspacing=0.25,
              handlelength=1.8, handletextpad=0.4, borderaxespad=0.15)
    ax.grid(lw=0.3, ls=":")
    # (e) K4 task-aware sensing
    ax = axs[1]
    fr = np.array(k4["frac"])
    pe = 100 * np.array(k4["pe"])
    scrb = np.array(k4["sum_crb"]) / (np.pi / 180) ** 2
    ax.plot(fr, pe, "k-", label="Decision error (task)")
    ax.set_yscale("log")
    ax.set_xlabel("Probing power share on target A")
    ax.set_ylabel("Mean decision error (%)")
    ax.set_xlim(0, 1)
    ax2 = ax.twinx()
    ax2.plot(fr, scrb, "--", color="0.45", label="Sum CRB (physical)")
    ax2.set_ylabel(r"Sum CRB (deg$^2$)", fontsize=6.5)
    ax2.set_yscale("log")
    ax2.tick_params(labelsize=6)
    for name, mk, lab in [("min_sum_crb", "o", "min sum-CRB"), ("equal", "^", "equal split"), ("task_aware", "s", "task-aware")]:
        f = k4["designs"][name]
        mc = 100 * k4["mc"][name]["pe"]
        ax.plot([f], [max(mc, 1e-2)], mk, color="#b30000", mfc="white", ms=4.5, label=f"ML sim.: {lab}")
    ax.set_title("(e) K4: task coupling", fontsize=7)
    ax.set_ylim(0.8 * pe.min(), 3e3)           # blank decades at the top for the legend
    ax.set_yticks([0.1, 1, 10])
    ax2.set_ylim(0.6 * scrb.min(), 3e3)
    ax2.set_yticks([1, 10])
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, loc="upper left", fontsize=5.2, labelspacing=0.22,
              handlelength=1.6, handletextpad=0.4, borderaxespad=0.15)
    ax.grid(lw=0.3, ls=":")
    # (f) K5 eavesdropper probe
    ax = axs[2]
    ntr = np.array(k5["n_train"])
    for key, lab, st, col in [("shared_stream", "Shared stream", "o-", "k"), ("known_probe", "Known probe", "^--", "0.4"),
                              ("an_probe", "Probe as AN", "s-", "#b30000")]:
        d = k5[key]["eve_probe_acc"]
        ax.errorbar(ntr, 100 * np.array(d["mean"]), yerr=100 * tot(d), fmt=st, color=col, mfc="white",
                    capsize=1.2, elinewidth=0.5, label=lab)
        ax.axhline(100 * k5[key]["bob_acc"]["mean"][0], color=col, lw=0.5, ls=":")
    ax.axhline(10, color="0.6", lw=0.6, ls="-")
    ax.set_ylim(0, 138)                        # blank band above the curves for the legend
    ax.set_yticks([0, 20, 40, 60, 80])
    ax.text(ntr[0] * 1.1, 2.5, "chance level", fontsize=6, color="0.4")
    ax.text(ntr[-1] * 0.95, 84, "legitimate user", fontsize=6, color="0.35", ha="right", va="bottom")
    ax.set_xscale("log")
    ax.set_xlabel("Labeled samples held by the eavesdropper")
    ax.set_ylabel("Eavesdropper task accuracy (%)")
    ax.set_title("(f) K5: security coupling", fontsize=7)
    ax.legend(frameon=False, loc="upper left", fontsize=5.4, ncol=2, columnspacing=0.7,
              handlelength=1.8, handletextpad=0.4, borderaxespad=0.15)
    ax.grid(lw=0.3, ls=":")
    fig.subplots_adjust(left=0.06, right=0.94, bottom=0.21, top=0.9, wspace=0.62)
    fig.savefig(os.path.join(OUT, f"fig_case_b.{EXT}"), dpi=160 if EXT == "png" else None)
    plt.close(fig)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    fig_a()
    fig_b()
    print("figures written to", OUT)
