"""Stage 1: train the CNN backbone on clean CIFAR-10 and cache features.

Usage: python scripts/train_backbone.py [--epochs 18] [--seed 0]
Outputs: results/backbone.pkl, results/features.npz
"""
from __future__ import annotations

import argparse
import os
import pickle
import sys
import time

import jax
import jax.numpy as jnp
import numpy as np
import optax

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from issc import data, nets  # noqa: E402

RES = os.path.join(os.path.dirname(__file__), "..", "results")


def save_ckpt(path, params, state, ep, it):
    """Atomic checkpoint write, so an interruption never leaves a truncated file."""
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        pickle.dump((jax.tree_util.tree_map(np.asarray, params),
                     jax.tree_util.tree_map(np.asarray, state), ep, it), f)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--subset", type=int, default=0, help="debug: use only N training images")
    ap.add_argument("--budget", type=float, default=0, help="stop after this many seconds (resumable)")
    args = ap.parse_args()
    os.makedirs(RES, exist_ok=True)

    x_tr, y_tr, x_te, y_te = data.load_cifar10()
    if args.subset:
        x_tr, y_tr = x_tr[: args.subset], y_tr[: args.subset]
    rng = np.random.default_rng(args.seed)
    params = nets.init_backbone(jax.random.PRNGKey(args.seed))
    steps = args.epochs * (len(x_tr) // args.batch)
    sched = optax.cosine_decay_schedule(args.lr, steps)
    opt = optax.adamw(sched, weight_decay=5e-4)
    state = opt.init(params)

    def loss_fn(p, x, y):
        logits = nets.backbone_logits(p, x)
        return optax.softmax_cross_entropy_with_integer_labels(logits, y).mean()

    @jax.jit
    def step(p, s, x, y):
        l, g = jax.value_and_grad(loss_fn)(p, x, y)
        upd, s = opt.update(g, s, p)
        return optax.apply_updates(p, upd), s, l

    @jax.jit
    def predict(p, x):
        return jnp.argmax(nets.backbone_logits(p, x), -1)

    def accuracy(p, x, y):
        preds = [np.asarray(predict(p, data.normalize(x[i:i + 500]))) for i in range(0, len(x), 500)]
        return float((np.concatenate(preds) == y).mean())

    ckpt = os.path.join(RES, "backbone_ckpt.pkl")
    ep0, it0 = 0, 0
    if os.path.exists(ckpt):  # resume after interruption (step-level)
        with open(ckpt, "rb") as f:
            params, state, ep0, it0 = pickle.load(f)
        print(f"resumed at epoch {ep0} step {it0}", flush=True)
    nb = len(x_tr) // args.batch
    t_start = time.time()
    for ep in range(ep0, args.epochs):
        perm = np.random.default_rng([args.seed, ep]).permutation(len(x_tr))
        for it in range(it0 if ep == ep0 else 0, nb):
            idx = perm[it * args.batch:(it + 1) * args.batch]
            arng = np.random.default_rng([args.seed, ep, it])
            xb = data.normalize(data.augment(x_tr[idx], arng))
            params, state, l = step(params, state, jnp.asarray(xb), jnp.asarray(y_tr[idx]))
            if (it + 1) % 50 == 0:
                save_ckpt(ckpt, params, state, ep, it + 1)
                if args.budget and time.time() - t_start > args.budget:
                    print(f"budget reached at epoch {ep} step {it + 1}", flush=True)
                    return
        acc = accuracy(params, x_te, y_te)
        print(f"epoch {ep + 1:02d} test_acc {acc:.4f}", flush=True)
        save_ckpt(ckpt, params, state, ep + 1, 0)

    with open(os.path.join(RES, "backbone.pkl"), "wb") as f:
        pickle.dump(jax.tree_util.tree_map(np.asarray, params), f)

    feat = jax.jit(nets.features)

    def all_feats(x):
        return np.concatenate([np.asarray(feat(params, data.normalize(x[i:i + 500]))) for i in range(0, len(x), 500)])

    x_tr_full, y_tr_full, _, _ = data.load_cifar10(check=False)
    np.savez_compressed(
        os.path.join(RES, "features.npz"),
        f_tr=all_feats(x_tr_full).astype(np.float32), y_tr=y_tr_full,
        f_te=all_feats(x_te).astype(np.float32), y_te=y_te,
        clean_acc=accuracy(params, x_te, y_te),
    )
    print("saved features", flush=True)


if __name__ == "__main__":
    main()
