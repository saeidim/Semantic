#!/bin/sh
# Run the five experiments one after another (each resumable by rerunning with --only).
cd "$(dirname "$0")/.."
for k in k1 k2 k3 k4 k5; do
  if [ ! -f results/$k.json ]; then python3 -W ignore -u scripts/run_experiments.py --only $k; fi
done
