"""Stage 3: controlled experiments for the five ISSC coupling mechanisms.

K1 resource coupling   : power split between semantic beam and sensing streams.
K2 waveform coupling   : semantic symbols used as the OFDM radar waveform.
K3 context coupling    : sensing-derived angle used to steer the semantic beam.
K4 task coupling       : task-aware versus physically optimal sensing allocation.
K5 security coupling   : the sensed target as a semantic eavesdropper.

Every experiment uses the same task (CIFAR-10 classification), the same
semantic representation (k = 32 complex symbols per image), the same metric
(clean-conditioned semantic outage) and the same randomness protocol
(S codec seeds x R Monte Carlo trials). Results go to results/k*.json.
"""
from __future__ import annotations

import argparse
import json
import os
import pickle
import sys

import jax
import jax.numpy as jnp
import numpy as np
import optax
from scipy.special import erfc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from issc import isac, nets  # noqa: E402
from issc.semantic import Tables, summarize  # noqa: E402

RES = os.path.join(os.path.dirname(__file__), "..", "results")
DEG = isac.DEG

# ---------------------------------------------------------------- scenario
N = 16                     # transmit = receive antennas (monostatic, colocated)
TH_U = -20 * DEG           # semantic user (SU)
TH_T = 30 * DEG            # sensed target (also the eavesdropper in K5)
K_DB = 10.0                # Rician K-factor of the downlink channels
SNR_U1_DB = 0.0            # SU SNR per transmit antenna at full power (P beta_u / sigma^2)
SNR_S_DB = -10.0           # echo SNR |b|^2 L P / sigma_s^2 (per receive antenna)
SNR_S_K4_DB = 6.0          # K4 uses a longer tracking dwell (integrated echo SNR of the stronger target)


def q(x):
    return 0.5 * erfc(x / np.sqrt(2))


def db(x):
    return 10 * np.log10(np.maximum(x, 1e-30))


def cov(*beams_and_powers):
    return sum(p * np.outer(w, w.conj()) for w, p in beams_and_powers)


# ---------------------------------------------------------------- K1
def k1(T: Tables, R: int, rng):
    alphas = np.linspace(0.02, 0.9, 23)
    snr_u1 = 10 ** (SNR_U1_DB / 10)
    snr_s = 10 ** (SNR_S_DB / 10)
    wc = isac.mrt(N, TH_U)
    v_iso = None
    v_cpl = isac.null_project(isac.mrt(N, TH_T), [TH_U], N)
    n_img = len(T.y)
    res = {"alpha": alphas.tolist()}
    for design in ("separated", "coupled"):
        out = np.zeros((len(T.seeds), R, len(alphas)))
        rmse = np.zeros(len(alphas))
        for ia, a in enumerate(alphas):
            if design == "separated":
                Rx = cov((wc, 1 - a)) + a * np.eye(N) / N
            else:
                Rx = cov((wc, 1 - a), (v_cpl, a))
            rmse[ia] = np.sqrt(isac.crb_angle(Rx, TH_T, snr_s)) / DEG
            for r in range(R):
                h = isac.rician(rng, n_img, N, TH_U, K_DB)          # (n_img, N)
                sig = (1 - a) * np.abs(h @ wc) ** 2
                if design == "separated":
                    intf = a * np.sum(np.abs(h) ** 2, axis=1) / N
                else:
                    intf = a * np.abs(h @ v_cpl) ** 2
                sinr_db = db(snr_u1 * sig / (snr_u1 * intf + 1.0))
                for si, s in enumerate(T.seeds):
                    out[si, r, ia] = T.outage("analog", s, sinr_db)
        res[design] = {"outage": summarize(out), "rmse_deg": rmse.tolist()}
    # sensing-only and semantic-only anchors
    res["rmse_sensing_only_deg"] = float(np.sqrt(isac.crb_angle(cov((isac.mrt(N, TH_T), 1.0)), TH_T, snr_s)) / DEG)
    return res


# ---------------------------------------------------------------- K2
def k2(T: Tables, R: int, rng):
    n_sc, m_sym = 256, 16
    kk = T.sym[f"analog_{T.seeds[0]}"].shape[1] // 2
    per_sym = n_sc // kk
    snr_db = np.arange(-20, 21, 2.0)          # strong-target echo SNR per subcarrier per symbol
    weak_rel_db = -30.0
    bins = (20, 83)
    pfa = 1e-3
    thr = -np.log(pfa)
    res = {"snr_db": snr_db.tolist(), "weak_rel_db": weak_rel_db}

    def frame(kind, seed):
        if kind == "pilot":
            return np.exp(2j * np.pi * rng.random((m_sym, n_sc)))
        sym = T.sym[f"{kind}_{seed}"]
        idx = rng.choice(len(sym), m_sym * per_sym, replace=False)
        s = nets.to_complex(sym[idx]).reshape(m_sym, n_sc)
        return s / np.sqrt(np.mean(np.abs(s) ** 2))

    n = np.arange(n_sc)
    steer_r = [np.exp(-2j * np.pi * n * b / n_sc) for b in bins]
    stats = {}
    for kind in ("pilot", "digital", "analog"):
        S_all = [frame(kind, s) for s in T.seeds for _ in range(4)]
        allsym = np.concatenate([x.ravel() for x in S_all])
        stats[kind] = {
            "e_inv": float(np.mean(1 / np.abs(allsym) ** 2)),
            "papr_sym_db": float(db(np.max(np.abs(allsym) ** 2) / np.mean(np.abs(allsym) ** 2))),
            "var_pow": float(np.var(np.abs(allsym) ** 2)),
        }
        for method in ("reciprocal", "matched"):
            pd = np.zeros((len(T.seeds), R, len(snr_db)))
            floor = np.zeros((len(T.seeds), R))
            for si, s in enumerate(T.seeds):
                for r in range(R):
                    S = frame(kind, s)
                    # noiseless strong-target profile -> data-induced floor
                    Y0 = S * steer_r[0][None, :]
                    p0 = isac.ofdm_range_profile(S, Y0, method)
                    mask = np.ones(n_sc, bool)
                    mask[[bins[0]]] = False
                    floor[si, r] = db(np.median(p0[mask]) / p0[bins[0]])
                    for j, sd in enumerate(snr_db):
                        a1 = np.sqrt(10 ** (sd / 10))
                        a2 = a1 * np.sqrt(10 ** (weak_rel_db / 10))
                        noise = (rng.standard_normal((m_sym, n_sc)) + 1j * rng.standard_normal((m_sym, n_sc))) / np.sqrt(2)
                        Y = S * (a1 * steer_r[0] + a2 * np.exp(1j * rng.uniform(0, 2 * np.pi)) * steer_r[1])[None, :] + noise
                        prof = isac.ofdm_range_profile(S, Y, method)
                        ref = np.ones(n_sc, bool)
                        for b in bins:
                            ref[max(b - 2, 0):b + 3] = False
                        noise_lvl = np.mean(prof[ref])
                        pd[si, r, j] = float(prof[bins[1]] > thr * noise_lvl)
            res[f"{kind}_{method}"] = {"pd": summarize(pd), "floor_db": summarize(floor[:, :, None])}
    res["symbol_stats"] = stats
    # semantic side: AWGN outage vs SNR for analog and digital codecs
    grid = np.arange(-10, 21, 1.0)
    for kind in ("analog", "digital"):
        o = np.zeros((len(T.seeds), 1, len(grid)))
        acc = np.zeros(len(T.seeds))
        for si, s in enumerate(T.seeds):
            o[si, 0] = [T.outage(kind, s, np.full(len(T.y), g)) for g in grid]
            acc[si] = T.clean_accuracy(kind, s)
        res[f"sem_{kind}"] = {"snr_db": grid.tolist(), "outage": summarize(o),
                              "clean_acc_mean": float(acc.mean()), "clean_acc_std": float(acc.std(ddof=1))}
    return res


# ---------------------------------------------------------------- K3
def k3(T: Tables, R: int, rng):
    th = 0.0
    snr1 = 10 ** (SNR_U1_DB / 10)
    bw = isac.hpbw(N)
    eps = np.logspace(-2, np.log10(2.0), 25)
    sizes = [16, 8, 4, 2, 1]
    n_img = len(T.y)
    Kl = 10 ** (K_DB / 10)

    def fading(n):
        # Rician small-scale fading on the dominant path of the V2I link
        return np.abs(np.sqrt(Kl / (Kl + 1)) + np.sqrt(1 / (Kl + 1)) *
                      (rng.standard_normal(n) + 1j * rng.standard_normal(n)) / np.sqrt(2)) ** 2

    def sinr_db(M, err, fad):
        n = np.arange(M)
        af = np.exp(1j * np.pi * np.outer(np.sin(th) - np.sin(th + err), n)).sum(axis=1)
        return db(snr1 * (np.abs(af) ** 2 / M) * fad)

    out = {M: np.zeros((len(T.seeds), R, len(eps))) for M in sizes}
    for ie, e in enumerate(eps):
        for r in range(R):
            err = rng.standard_normal(n_img) * e * bw      # paired across beam sizes
            fad = fading(n_img)
            for M in sizes:
                sd = sinr_db(M, err, fad)
                for si, s in enumerate(T.seeds):
                    out[M][si, r, ie] = T.outage("analog", s, sd)
    # uncertainty-aware policy: choose M from independent calibration draws (seed 0),
    # then evaluate on the stored evaluation draws above
    choice = []
    for ie, e in enumerate(eps):
        err = rng.standard_normal(n_img) * e * bw
        fad = fading(n_img)
        cal = {M: T.outage("analog", T.seeds[0], sinr_db(M, err, fad)) for M in sizes}
        choice.append(min(cal, key=cal.get))
    adaptive = np.stack([out[choice[ie]][:, :, ie] for ie in range(len(eps))], axis=-1)
    res = {"eps": eps.tolist(), "hpbw_deg": bw / DEG, "sizes": sizes, "choice": choice,
           "adaptive": summarize(adaptive)}
    for M in sizes:
        res[f"M{M}"] = summarize(out[M])
    m16, m1 = np.array(res["M16"]["mean"]), np.array(res["M1"]["mean"])
    idx = np.where(m16 > m1)[0]
    if len(idx):
        i = idx[0]
        x0, x1 = np.log10(eps[i - 1]), np.log10(eps[i])
        d0, d1 = (m16 - m1)[i - 1], (m16 - m1)[i]
        res["eps_star"] = float(10 ** (x0 - d0 * (x1 - x0) / (d1 - d0)))
    return res


# ---------------------------------------------------------------- K4
def k4(rng, n_mc: int = 200000):
    """Two targets share a sensing budget; each has a binary decision
    (inside/outside a protected sector) whose boundary lies delta_i away."""
    snr_s = 10 ** (SNR_S_K4_DB / 10)
    tgt = {"A": {"theta": -35 * DEG, "rel_db": -12.0, "delta": 4.0 * DEG},   # weak echo, easy decision
           "B": {"theta": 25 * DEG, "rel_db": 0.0, "delta": 0.35 * DEG}}     # strong echo, hard decision
    for t in tgt.values():
        w = isac.mrt(N, t["theta"])
        t["c"] = isac.crb_angle(np.outer(w, w.conj()), t["theta"], snr_s * 10 ** (t["rel_db"] / 10))
    fr = np.linspace(0.01, 0.99, 197)                  # power fraction on target A
    crb_a, crb_b = tgt["A"]["c"] / fr, tgt["B"]["c"] / (1 - fr)
    pe = 0.5 * (q(tgt["A"]["delta"] / np.sqrt(crb_a)) + q(tgt["B"]["delta"] / np.sqrt(crb_b)))
    sum_rmse = np.sqrt(crb_a) + np.sqrt(crb_b)
    sum_crb = crb_a + crb_b
    designs = {
        "equal": 0.5,
        "min_sum_crb": np.sqrt(tgt["A"]["c"]) / (np.sqrt(tgt["A"]["c"]) + np.sqrt(tgt["B"]["c"])),
        "min_max_crb": tgt["A"]["c"] / (tgt["A"]["c"] + tgt["B"]["c"]),
        "task_aware": float(fr[np.argmin(pe)]),
    }

    # Monte Carlo validation with the ML estimator on the same echo model.
    # Y = amp e^{j phi} a_r(theta) a_t(theta)^T X + W with X = sqrt(p) w z^T, so that
    # the sufficient statistic for the angle is u = Y z^* (see isac.ml_angle_batch).
    L = 64

    def mc(frac, chunk: int = 4000):
        errs, sq = {}, {}
        for name, t in tgt.items():
            p = frac if name == "A" else 1 - frac
            amp = np.sqrt(snr_s * 10 ** (t["rel_db"] / 10) / L)
            sig = amp * np.sqrt(p) * np.sqrt(N) * L          # coherent gain of the matched vector
            grid = t["theta"] + np.arange(-400, 401) * 0.02 * DEG
            e, s2 = 0, 0.0
            for i0 in range(0, n_mc, chunk):
                m = min(chunk, n_mc - i0)
                ar = isac.steer(N, t["theta"])
                phase = np.exp(1j * rng.uniform(0, 2 * np.pi, (m, 1)))
                U = sig * phase * ar[None, :] + np.sqrt(L / 2) * (
                    rng.standard_normal((m, N)) + 1j * rng.standard_normal((m, N)))
                est = isac.ml_angle_batch(U, grid, N)
                e += int(np.sum(est > t["theta"] + t["delta"]))
                s2 += float(np.sum((est - t["theta"]) ** 2))
            errs[name] = e
            sq[name] = np.sqrt(s2 / n_mc)
        return {"pe": 0.5 * (errs["A"] + errs["B"]) / n_mc,
                "pe_A": errs["A"] / n_mc, "pe_B": errs["B"] / n_mc,
                "rmse_A_deg": float(sq["A"] / DEG), "rmse_B_deg": float(sq["B"] / DEG)}

    val = {k: mc(v) for k, v in designs.items()}
    return {"frac": fr.tolist(), "pe": pe.tolist(), "sum_rmse_deg": (sum_rmse / DEG).tolist(),
            "sum_crb": sum_crb.tolist(), "designs": {k: float(v) for k, v in designs.items()},
            "mc": val, "n_mc": n_mc, "snr_s_db": SNR_S_K4_DB, "targets": {k: {"theta_deg": v["theta"] / DEG, "rel_db": v["rel_db"],
                                        "delta_deg": v["delta"] / DEG} for k, v in tgt.items()}}


# ---------------------------------------------------------------- K5
def train_probe(x, y, steps=400, lr=0.05, l2=1e-3, seed=0):
    """Multinomial logistic regression (the eavesdropper's surrogate task head)."""
    d = x.shape[1]
    p = {"w": jnp.zeros((d, 10)), "b": jnp.zeros(10)}
    opt = optax.adam(lr)
    st = opt.init(p)

    def loss(p):
        lg = x @ p["w"] + p["b"]
        return optax.softmax_cross_entropy_with_integer_labels(lg, y).mean() + l2 * jnp.sum(p["w"] ** 2)

    @jax.jit
    def step(p, st):
        g = jax.grad(loss)(p)
        u, st = opt.update(g, st, p)
        return optax.apply_updates(p, u), st

    for _ in range(steps):
        p, st = step(p, st)
    return p


def k5(T: Tables, R: int, rng):
    with open(os.path.join(RES, "codecs.pkl"), "rb") as f:
        C = pickle.load(f)
    d = np.load(os.path.join(RES, "features.npz"))
    f_tr = d["f_tr"] / C["feat_scale"]
    y_tr = d["y_tr"]
    snr_u1 = 10 ** (SNR_U1_DB / 10)
    snr_e1 = 10 ** ((SNR_U1_DB + 6.0) / 10)          # the eavesdropper is closer than the user
    snr_s = 10 ** (SNR_S_DB / 10)
    zeta = 0.3                                        # power share devoted to illuminating the target
    wu, we = isac.mrt(N, TH_U), isac.mrt(N, TH_T)
    wd = np.sqrt(1 - zeta) * wu + np.sqrt(zeta) * we
    wd /= np.linalg.norm(wd)
    wu_zf = isac.null_project(wu, [TH_T], N)
    we_zf = isac.null_project(we, [TH_U], N)
    designs = {
        # (semantic beam, semantic power, probing beam, probing power, probing known to Eve?)
        "shared_stream": (wd, 1.0, None, 0.0, True),
        "known_probe": (wu, 1 - zeta, we, zeta, True),
        "an_probe": (wu_zf, 1 - zeta, we_zf, zeta, False),
    }
    n_tr_list = [100, 300, 1000, 3000, 10000]
    n_te = len(T.y)
    res = {"n_train": n_tr_list, "zeta": zeta}
    for name, (ws, ps, wp, pp, known) in designs.items():
        Rx = cov((ws, ps)) + (cov((wp, pp)) if wp is not None else 0)
        crb = isac.crb_angle(Rx, TH_T, snr_s)
        bob_out = np.zeros((len(T.seeds), R, 1))
        eve_acc = np.zeros((len(T.seeds), R, len(n_tr_list)))
        eve_kb = np.zeros((len(T.seeds), R, 1))
        bob_acc = np.zeros((len(T.seeds), R, 1))
        for si, s in enumerate(T.seeds):
            codec = C["codecs"][("analog", s)]
            s_tr = np.asarray(nets.modulate(codec, jnp.asarray(f_tr[:max(n_tr_list)]), False))
            s_te = T.sym[f"analog_{s}"]
            for r in range(R):
                hu = isac.rician(rng, n_te, N, TH_U, K_DB)
                sig_u = ps * np.abs(hu @ ws) ** 2
                int_u = 0.0 if (wp is None or known) else pp * np.abs(hu @ wp) ** 2
                sinr_u = db(snr_u1 * sig_u / (snr_u1 * int_u + 1))
                bob_out[si, r, 0] = T.outage("analog", s, sinr_u)
                bob_acc[si, r, 0] = T.accuracy("analog", s, sinr_u)

                def eve_sinr(n):
                    he = isac.rician(rng, n, N, TH_T, K_DB)
                    sig = ps * np.abs(he @ ws) ** 2
                    intf = 0.0 if (wp is None or known) else pp * np.abs(he @ wp) ** 2
                    return snr_e1 * sig / (snr_e1 * intf + 1)

                def received(sym, sinr):
                    sig = np.sqrt(0.5 / sinr)[:, None]
                    return sym + sig * rng.standard_normal(sym.shape)

                y_te_e = received(s_te, eve_sinr(n_te))
                # eavesdropper holding the legitimate task head (knowledge base leaked)
                lg = y_te_e @ codec["dec"]["w"] + codec["dec"]["b"]
                eve_kb[si, r, 0] = np.mean(np.argmax(lg, -1) == T.y)
                y_tr_e = received(s_tr, eve_sinr(len(s_tr)))
                for j, ntr in enumerate(n_tr_list):
                    p = train_probe(jnp.asarray(y_tr_e[:ntr]), jnp.asarray(y_tr[:ntr]))
                    pred = np.argmax(y_te_e @ np.asarray(p["w"]) + np.asarray(p["b"]), -1)
                    eve_acc[si, r, j] = np.mean(pred == T.y)
        res[name] = {"rmse_deg": float(np.sqrt(crb) / DEG), "bob_outage": summarize(bob_out),
                     "bob_acc": summarize(bob_acc), "eve_probe_acc": summarize(eve_acc),
                     "eve_kb_acc": summarize(eve_kb)}
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="k1,k2,k3,k4,k5")
    ap.add_argument("--R", type=int, default=10)
    args = ap.parse_args()
    T = Tables()
    todo = args.only.split(",")
    for name in todo:
        rng = np.random.default_rng({"k1": 1, "k2": 2, "k3": 3, "k4": 4, "k5": 5}[name])
        if name == "k4":
            out = k4(rng)
        elif name == "k5":
            out = k5(T, max(2, args.R // 5), rng)
        else:
            out = globals()[name](T, args.R, rng)
        out["scenario"] = {"N": N, "theta_u_deg": TH_U / DEG, "theta_t_deg": TH_T / DEG, "K_dB": K_DB,
                           "snr_u1_dB": SNR_U1_DB, "snr_s_dB": SNR_S_DB, "seeds": T.seeds, "R": args.R}
        with open(os.path.join(RES, f"{name}.json"), "w") as f:
            json.dump(out, f, indent=1)
        print(f"{name} done", flush=True)


if __name__ == "__main__":
    main()
