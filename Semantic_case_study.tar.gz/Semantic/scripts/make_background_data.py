"""Compute the numbers behind the background (tutorial) figures of the survey.

Writes results/background.json with
  * the classical rate-CRB fronts of the tutorial scenario (isotropic and
    null-space probing), which Fig. "ISAC essentials" plots, and
  * the measured semantic success curve xi(gamma) of the analog and digital
    codecs, with a logistic fit, which Fig. "SemCom essentials" plots.

Run after scripts/run_experiments.py (it reuses results/k2.json).
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
from scipy.optimize import curve_fit

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from issc import isac  # noqa: E402

RES = os.path.join(os.path.dirname(__file__), "..", "results")

N = 16                      # transmit and receive antennas
TH_U = -20 * isac.DEG       # semantic user
TH_T = 30 * isac.DEG        # sensed target
SNR_U_DB = 0.0              # per-antenna downlink SNR at full power
SNR_S_DB = -10.0            # echo SNR per receive antenna


def fronts():
    """Classical rate versus angle-RMSE fronts as the probing share alpha varies."""
    rho, snr_s = 10 ** (SNR_U_DB / 10), 10 ** (SNR_S_DB / 10)
    a_u = isac.steer(N, TH_U)
    w_c = isac.mrt(N, TH_U)                       # communication beam
    w_s = isac.mrt(N, TH_T)                       # probing beam towards the target
    w_s_null = isac.null_project(w_s, [TH_U], N)  # probing beam nulled at the user
    alphas = np.linspace(0.0, 0.9, 46)
    out = {"alpha": alphas.tolist()}
    for name, R_s, leak in [
        ("isotropic", np.eye(N) / N, np.abs(a_u @ (np.eye(N) / N) @ a_u.conj()) / 1.0),
        ("nullspace", np.outer(w_s_null, w_s_null.conj()), np.abs(a_u @ w_s_null) ** 2),
    ]:
        rate, rmse = [], []
        for al in alphas:
            gam = rho * (1 - al) * np.abs(a_u @ w_c) ** 2 / (rho * al * np.real(leak) + 1.0)
            R = (1 - al) * np.outer(w_c, w_c.conj()) + al * R_s
            rate.append(float(np.log2(1 + gam)))
            rmse.append(float(np.sqrt(isac.crb_angle(R, TH_T, snr_s)) / isac.DEG))
        out[name] = {"rate_bps_hz": rate, "rmse_deg": rmse}
    # reference points
    R_sense = np.outer(isac.mrt(N, TH_T), isac.mrt(N, TH_T).conj())
    out["sensing_only_rmse_deg"] = float(np.sqrt(isac.crb_angle(R_sense, TH_T, snr_s)) / isac.DEG)
    out["comm_only_rate_bps_hz"] = float(np.log2(1 + rho * np.abs(a_u @ w_c) ** 2))
    return out


def logistic(g, g50, s):
    return 1.0 / (1.0 + np.exp(-(g - g50) / s))


def semantic_curve():
    """Measured task success versus post-equalisation SNR, with a logistic fit."""
    with open(os.path.join(RES, "k2.json")) as f:
        k2 = json.load(f)
    out = {}
    for kind in ("analog", "digital"):
        d = k2[f"sem_{kind}"]
        g = np.array(d["snr_db"], dtype=float)
        xi = 1.0 - np.array(d["outage"]["mean"], dtype=float)
        p, _ = curve_fit(logistic, g, xi, p0=[-5.0, 3.0], maxfev=20000)
        out[kind] = {"snr_db": g.tolist(), "xi": xi.tolist(),
                     "fit": {"g50_db": float(p[0]), "slope_db": float(p[1])},
                     "clean_acc": float(d["clean_acc_mean"])}
    return out


if __name__ == "__main__":
    data = {"scenario": {"n_ant": N, "user_deg": TH_U / isac.DEG, "target_deg": TH_T / isac.DEG,
                         "snr_user_db": SNR_U_DB, "snr_echo_db": SNR_S_DB},
            "fronts": fronts(), "semantic": semantic_curve()}
    with open(os.path.join(RES, "background.json"), "w") as f:
        json.dump(data, f, indent=1)
    f0 = data["fronts"]
    print("rate range", round(min(f0['isotropic']['rate_bps_hz']), 2), round(max(f0['isotropic']['rate_bps_hz']), 2))
    print("rmse range", round(min(f0['nullspace']['rmse_deg']), 3), round(max(f0['isotropic']['rmse_deg']), 3))
    print("sensing-only rmse", round(f0["sensing_only_rmse_deg"], 3), "comm-only rate", round(f0["comm_only_rate_bps_hz"], 2))
    for k, v in data["semantic"].items():
        print(k, "gamma50", round(v["fit"]["g50_db"], 2), "dB slope", round(v["fit"]["slope_db"], 2))
