#!/bin/sh
# Relaunch the resumable backbone training if it is not running and not finished.
cd "$(dirname "$0")/.."
if [ -f results/features.npz ]; then echo "finished"; exit 0; fi
if ps -eo cmd | grep -v grep | grep -q "train_backbone.py"; then echo "running"; else
  setsid nohup python3 -W ignore -u scripts/train_backbone.py --epochs 12 >> results/train_backbone.log 2>&1 < /dev/null &
  echo "relaunched"; fi
tail -3 results/train_backbone.log
