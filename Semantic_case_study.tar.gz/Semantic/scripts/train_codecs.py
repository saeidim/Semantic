"""Stage 2: train analog and digital semantic codecs over the frozen backbone.

For every seed s in 0..S-1 and codec type in {analog, digital} we train a
linear semantic encoder (256 -> 2k reals -> k complex symbols) and a linear
task head over an AWGN channel whose SNR is drawn per image, uniformly in
dB over [snr_lo, snr_hi]. Afterwards we tabulate, for every test image, the
probability of a task error as a function of the effective post-equalisation
SNR. All experiments (K1 to K5) read these tables, so that every mechanism is
evaluated with the same task, representation, metric and randomness.

Outputs: results/codecs.pkl, results/perr_tables.npz
"""
from __future__ import annotations

import argparse
import os
import pickle
import sys
import time

import jax
import jax.numpy as jnp
import numpy as np
import optax

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from issc import nets  # noqa: E402

RES = os.path.join(os.path.dirname(__file__), "..", "results")
SNR_GRID_DB = np.arange(-15.0, 30.01, 0.5)


def train_one(f_tr, y_tr, seed, digital, k_sym, epochs, snr_lo, snr_hi, batch=256, lr=3e-3):
    key = jax.random.PRNGKey(1000 * seed + (1 if digital else 0))
    params = nets.init_codec(key, k_sym)
    steps = epochs * (len(f_tr) // batch)
    opt = optax.adam(optax.cosine_decay_schedule(lr, steps))
    state = opt.init(params)

    def loss_fn(p, f, y, key):
        s = nets.modulate(p, f, digital)
        k1, _ = jax.random.split(key)
        snr_db = jax.random.uniform(k1, (f.shape[0], 1), minval=snr_lo, maxval=snr_hi)
        sigma = jnp.sqrt(0.5 / 10 ** (snr_db / 10))
        noise = sigma * jax.random.normal(jax.random.fold_in(key, 7), s.shape)
        logits = nets.decode(p, s + noise)
        return optax.softmax_cross_entropy_with_integer_labels(logits, y).mean()

    @jax.jit
    def step(p, st, f, y, key):
        l, g = jax.value_and_grad(loss_fn)(p, f, y, key)
        u, st = opt.update(g, st, p)
        return optax.apply_updates(p, u), st, l

    rng = np.random.default_rng(seed)
    key = jax.random.PRNGKey(seed + 17)
    for ep in range(epochs):
        perm = rng.permutation(len(f_tr))
        for i in range(0, len(perm) - batch + 1, batch):
            idx = perm[i:i + batch]
            key, sub = jax.random.split(key)
            params, state, _ = step(params, state, f_tr[idx], y_tr[idx], sub)
    return jax.tree_util.tree_map(np.asarray, params)


def perr_table(params, f_te, y_te, digital, n_draw, seed):
    """P(task error | effective SNR) for every test image, shape (N_test, len(SNR_GRID_DB))."""
    rng = np.random.default_rng(10_000 + seed)
    s = np.asarray(nets.modulate(params, f_te, digital))
    clean_pred = np.argmax(np.asarray(nets.decode(params, s)), -1)
    W, b = params["dec"]["w"], params["dec"]["b"]
    out = np.empty((len(f_te), len(SNR_GRID_DB)), dtype=np.float32)
    for j, snr_db in enumerate(SNR_GRID_DB):
        sigma = np.sqrt(0.5 / 10 ** (snr_db / 10))
        err = np.zeros(len(f_te))
        for _ in range(n_draw):
            y = s + sigma * rng.standard_normal(s.shape).astype(np.float32)
            err += np.argmax(y @ W + b, -1) != y_te
        out[:, j] = err / n_draw
    return out, clean_pred == y_te, s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--k", type=int, default=32, help="complex channel symbols per image")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--snr_lo", type=float, default=-10.0)
    ap.add_argument("--snr_hi", type=float, default=20.0)
    ap.add_argument("--draws", type=int, default=16)
    args = ap.parse_args()

    d = np.load(os.path.join(RES, "features.npz"))
    f_tr, y_tr, f_te, y_te = d["f_tr"], d["y_tr"], d["f_te"], d["y_te"]
    scale = f_tr.std()
    f_tr, f_te = f_tr / scale, f_te / scale
    codecs, tables, clean_ok, symbols = {}, {}, {}, {}
    for kind in ("analog", "digital"):
        for s in range(args.seeds):
            t0 = time.time()
            p = train_one(jnp.asarray(f_tr), jnp.asarray(y_tr), s, kind == "digital", args.k,
                          args.epochs, args.snr_lo, args.snr_hi)
            tab, ok, sym = perr_table(p, f_te, y_te, kind == "digital", args.draws, s)
            codecs[(kind, s)] = p
            tables[f"{kind}_{s}"] = tab
            clean_ok[f"{kind}_{s}"] = ok
            symbols[f"{kind}_{s}"] = sym.astype(np.float32)
            print(f"{kind} seed {s}: clean acc {ok.mean():.4f} ({time.time() - t0:.0f}s)", flush=True)
    with open(os.path.join(RES, "codecs.pkl"), "wb") as f:
        pickle.dump({"codecs": codecs, "feat_scale": float(scale), "k": args.k, "args": vars(args)}, f)
    np.savez_compressed(os.path.join(RES, "perr_tables.npz"), snr_grid_db=SNR_GRID_DB,
                        **{f"perr_{k}": v for k, v in tables.items()},
                        **{f"ok_{k}": v for k, v in clean_ok.items()},
                        **{f"sym_{k}": v for k, v in symbols.items()}, y_te=y_te)
    print("done", flush=True)


if __name__ == "__main__":
    main()
